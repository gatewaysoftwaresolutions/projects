# [2.40.0](https://github.com/hossainchisty/LeafLine-Client/compare/v2.39.0...v2.40.0) (2024-01-28)


### Features

* Added umami analytics ([b2e7010](https://github.com/hossainchisty/LeafLine-Client/commit/b2e701008d6062e3137fd79b7180a5977a122374))



# [2.39.0](https://github.com/hossainchisty/LeafLine-Client/compare/v2.38.0...v2.39.0) (2024-01-28)


### Features

* User can see all orders ([dbc5d7f](https://github.com/hossainchisty/LeafLine-Client/commit/dbc5d7f323ffc9212af9218cb0b67a43406233bc))



# [2.38.0](https://github.com/hossainchisty/LeafLine-Client/compare/v2.37.0...v2.38.0) (2024-01-21)


### Features

* Added hero section for better UI ([ae81929](https://github.com/hossainchisty/LeafLine-Client/commit/ae81929f559cdb42f899e957d92a32320d06eafd))



# [2.37.0](https://github.com/hossainchisty/LeafLine-Client/compare/v2.36.4...v2.37.0) (2023-10-18)


### Features

* Add demo UI of invite ([76a1f51](https://github.com/hossainchisty/LeafLine-Client/commit/76a1f5109741cee5ebd0e7b19e57686c6e471972))



## [2.36.4](https://github.com/hossainchisty/LeafLine-Client/compare/v2.36.3...v2.36.4) (2023-10-17)


### Bug Fixes

* cart items remove functionality ([2e4106b](https://github.com/hossainchisty/LeafLine-Client/commit/2e4106bf16da1608cec04e422c86872ce399e22f))



