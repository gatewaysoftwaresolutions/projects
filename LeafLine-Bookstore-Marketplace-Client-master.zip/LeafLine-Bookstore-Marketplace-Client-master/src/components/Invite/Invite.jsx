const Invite = () => {
  return <div>Invite</div>;
};

export default Invite;
