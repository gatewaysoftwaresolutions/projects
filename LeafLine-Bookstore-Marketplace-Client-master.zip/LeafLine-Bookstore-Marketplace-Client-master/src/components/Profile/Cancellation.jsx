const Cancellation = () => {
  return <div>My Cancellations</div>;
};

export default Cancellation;
