const Refunds = () => {
  return <div>Refunds</div>;
};

export default Refunds;
