const Returns = () => {
  return <div>My Returns</div>;
};

export default Returns;
