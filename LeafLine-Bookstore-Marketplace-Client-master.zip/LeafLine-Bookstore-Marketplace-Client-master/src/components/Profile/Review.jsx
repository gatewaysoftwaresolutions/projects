const Review = () => {
  return <div>My Reviews</div>;
};

export default Review;
