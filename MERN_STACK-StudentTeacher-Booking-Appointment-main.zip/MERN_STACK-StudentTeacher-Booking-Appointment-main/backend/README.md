# Student-Teacher-Appointment-Backend

.env file
db_conn=''
JWT_KEY =
