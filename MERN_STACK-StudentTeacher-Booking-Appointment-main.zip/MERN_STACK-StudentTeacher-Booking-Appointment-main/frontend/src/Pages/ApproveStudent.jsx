import React from 'react'

function ApproveStudent() {
    document.body.style.overflow = 'hidden';
    return (
        <div className="flex min-h-screen justify-center items-center dark:bg-slate-900 ">
            <div className='text-4xl font-medium'>Your Are Not Approved From Admin</div>
        </div>
    )
}

export default ApproveStudent