export default function ({ children }) {
    return <div className='group'>
        {children}
    </div>
}