import React from 'react'

export default function Details() {
  return (
    <div>Details</div>
  )
}
